package com.inn.service;

public class faqService {

}
