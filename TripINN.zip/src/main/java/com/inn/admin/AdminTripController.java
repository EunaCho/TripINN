package com.inn.admin;

import org.springframework.stereotype.Controller;

@Controller
public class AdminTripController {

}
