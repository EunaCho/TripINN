package com.inn.faq;

public class faqController {

}
